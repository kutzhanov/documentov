<?php

class ModelToolUpdate extends Model
{


  public function manualUpdate()
  {
    $var = $this->variable->get('manual_update');
    if ($var) {
      $methods = explode(",", $var);
      foreach ($methods as $method_name) {
        if (method_exists($this, $method_name)) {
          $this->$method_name();
        }
      }
    }
    $this->variable->set('manual_update', '');
    $this->setManualUpdate("");
  }

  public function update()
  {
    $versions = array();
    for ($i = 0; $i <= 9; $i++) {
      for ($k = 0; $k <= 9; $k++) {
        for ($m = 0; $m <= 9; $m++) {
          $versions[] = $i . "." . $k . "." . $m;
        }
      }
    }
    $version_db = $this->config->get('version_db'); //версия БД, версия кода в VERSION. Нужно выполнить все обновления, начиная с версии БД
    if (!$version_db) {
      $version_db = '0.5.0';
    }
    if ($version_db != VERSION) {
      $start = false;
      foreach ($versions as $version) {
        if ($version == VERSION) {
          break;
        }
        if ($version == $version_db) {
          $start = true;
        }
        if ($start) {
          $this->updateTo($version);
        }
      }
      $this->load->model('setting/setting');
      $this->model_setting_setting->editSetting('dv_system', array('version_db' => VERSION));
    }
  }

  public function updateTo($version)
  {
    $this->load->model('doctype/doctype');
    $this->load->model('document/document');
    switch ($version) {
      case "1.0.9": //обновляем 1.0.9 до 1.1.0
        if (!$this->isTableColumn("button_group")) {
          $this->db->query("CREATE TABLE " . DB_PREFIX . "button_group (`button_group_uid` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL, `container_uid` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL, `picture` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, `hide_group_name` smallint(6) NOT NULL, `color` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL, `background` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL, `draft` tinyint(4) NOT NULL, `draft_params` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
        }
        if (!$this->isTableColumn("button_group_description")) {
          $this->db->query("CREATE TABLE " . DB_PREFIX . "button_group_description (`button_group_uid` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL, `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, `language_id` int(11) NOT NULL) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
        }
        if (!$this->isTableColumn("route_button", "button_group_uid")) {
          $this->db->query("ALTER TABLE " . DB_PREFIX . "route_button ADD `button_group_uid` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL AFTER `route_uid`;");
        }
        if (!$this->isTableColumn('doctype_template', 'conditions')) {
          $this->db->query("ALTER TABLE " . DB_PREFIX . "doctype_template ADD `conditions` MEDIUMTEXT NOT NULL AFTER `template`;");
        }
        break;
      case "1.1.2":
        if (!$this->isTableColumn("folder_field", "tcolumn_width")) {
          $this->db->query("ALTER TABLE " . DB_PREFIX . "folder_field ADD `tcolumn_width` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL AFTER `tcolumn_name`;");
        }
        break;
      case "1.1.9":
        $this->load->model('setting/extension');

        $type_string = "string";
        if ($this->model_setting_extension->getExtensionId('field', 'string_plus')) {
          $type_string = "string_plus";
        }
        $type_text = "text";
        if ($this->model_setting_extension->getExtensionId('field', 'text_plus')) {
          $type_text = "text_plus";
        }
        $field_string_params = array(
          'mask'          => ''
        );
        $field_text_params = array(
          'editor_enabled'          => ''
        );

        $field_description = 'График рабочего времени, используемый по умолчанию полем Время. Формат: НОМЕР_ДНЯ_НЕДЕЛИ:РАБ_ЧАС1, РАБ_ЧАС2, РАБ_ЧАС3; Например, для шестидневной рабочей недели (с пн по пт с 9 до 17, с обедом с 13 до 14; в сб - с 9 до 14 без обеда): 1:9,10,11,12,14,15,16; 2:9,10,11,12,14,15,16; 3:9,10,11,12,14,15,16; 4:9,10,11,12,14,15,16; 5:9,10,11,12,14,15,16; 6:9,10,11,12,13';
        $this->addField('b9e08649-8132-11e9-aefb-7c2a31f58480', 'РАБОЧИЙ ГРАФИК', '51f80627-1df9-11e8-a7fb-201a06f86b88', $type_string, serialize($field_string_params), 11, 1, $field_description);

        $field_description = 'Дополнительные выходные и праздничные дни, используемые полем Время. Формат:  ГГГГ-ММ-ДД; ГГГГ-ММ-ДД Например, 2020-01-01; 2020-08-03; 2020-05-09';
        $this->addField('b9e08649-8132-11e9-aefb-7c2a31f58481', 'ПРАЗДНИЧНЫЕ ДНИ', '51f80627-1df9-11e8-a7fb-201a06f86b88', $type_text, serialize($field_text_params), 12, 1, $field_description);

        $field_description = 'Дни с нестандартным рабочим временем или рабочие выходые, используемые полем Время. Формат: ГГГГ-ММ-ДД:РАБ_ЧАС1, РАБ_ЧАС2; Например, 2020-12-31:9,10,11,12;2020-03-07:9,10,11,12,13,14';
        $this->addField('b9e08649-8132-11e9-aefb-7c2a31f58482', 'НЕСТАНДАРТНЫЕ РАБОЧИЕ ДНИ', '51f80627-1df9-11e8-a7fb-201a06f86b88', $type_text, serialize($field_text_params), 13, 1, $field_description);

        $this->model_document_document->editFieldValue('b9e08649-8132-11e9-aefb-7c2a31f58480', 0, '1:9,10,11,12,14,15,16,17; 2:9,10,11,12,14,15,16,17; 3:9,10,11,12,14,15,16,17; 4:9,10,11,12,14,15,16,17; 5:9,10,11,12,14,15,16,17');
        $this->model_document_document->editFieldValue('b9e08649-8132-11e9-aefb-7c2a31f58481', 0, '2020-01-01; 2020-03-08');
        $this->model_document_document->editFieldValue('b9e08649-8132-11e9-aefb-7c2a31f58482', 0, '2019-12-31:9,10,11,12; 2019-03-07:9,10,11,12,14,16');

        $this->addSetting('dv_field_datetime', 'worktime_field_uid', 'b9e08649-8132-11e9-aefb-7c2a31f58480');
        $this->addSetting('dv_field_datetime', 'holidays_field_uid', 'b9e08649-8132-11e9-aefb-7c2a31f58481');
        $this->addSetting('dv_field_datetime', 'irregular_worktime_field_uid', 'b9e08649-8132-11e9-aefb-7c2a31f58482');
        break;
      case "1.2.0":
        $text_tables = ['field_value_text', 'field_value_text_plus'];
        foreach ($text_tables as $table) {
          if ($this->isTableColumn($table)) {
            $this->db->query("UPDATE " . DB_PREFIX . $table . " SET `value` = replace(`value`, '__amprsnd__', '&')");
            $this->db->query("UPDATE " . DB_PREFIX . $table . " SET `display_value` = replace(`display_value`, '__amprsnd__', '&')");
          }
        }
        break;
      default:
        break;
    }
  }

  /**
   * Установка переменной необходимости ручного обновления, запускаемого администратором в удобное для него время.
   * @param type $update - метод для запуска; если метода нет, переменная стирается
   */
  protected function setManualUpdate($update)
  {
    $this->load->model('setting/variable');
    if ($update) {
      $var = $this->model_setting_variable->getVar('manual_update');
      if ($var) {
        $update = $var . "," . $update;
      }
    }
    $this->model_setting_variable->setVar('manual_update', $update);
  }

  protected function addSetting($code, $key, $value)
  {
    $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "setting WHERE `key` = '" . $this->db->escape($key) . "' ");
    if ($query->num_rows) {
      $this->db->query("UPDATE " . DB_PREFIX . "setting SET `code` = '" . $this->db->escape($code) . "', `value` = '" . $this->db->escape($value) . "' WHERE `key` = '" . $this->db->escape($key) . "' ");
    } else {
      $this->db->query("INSERT INTO " . DB_PREFIX . "setting (`store_id`, `code`, `key`, `value`, `serialized`) "
        . "VALUES ('0', '" . $this->db->escape($code) . "', '" . $this->db->escape($key) . "', '" . $this->db->escape($value) . "', '0')");
    }
  }

  protected function addField($field_uid, $name, $doctype_uid, $field_type, $params, $sort, $setting = 0, $description = '')
  {
    $query = $this->db->query("SELECT field_uid FROM " . DB_PREFIX . "field WHERE field_uid = '" . $this->db->escape($field_uid) . "' ");
    if (!$query->num_rows) {
      //поля нет, теперь проверим наличие типа документа, в который добавляется это поле
      $query_dt = $this->db->query("SELECT doctype_uid FROM " . DB_PREFIX . "doctype WHERE doctype_uid = '" . $this->db->escape($doctype_uid) . "' ");
      if (!$query_dt->num_rows) {
        //типа документа нет
        return;
      }
      $this->db->query("INSERT INTO `field` (`field_uid`, `name`, `doctype_uid`, `type`, `setting`, `change_field`, `access_form`, `access_view`, "
        . "`required`, `unique`, `params`, `sort`, `draft`, `draft_params`, `description`) "
        . "VALUES ('" . $this->db->escape($field_uid) . "', "
        . "'" . $this->db->escape($name) . "', "
        . "'" . $this->db->escape($doctype_uid) . "', "
        . "'" . $this->db->escape($field_type) . "', "
        . "'" . (int)$setting . "', '0', '', '', '0', '0', "
        . "'" . $this->db->escape($params) . "', '" . (int)$sort . "', '0', '', "
        . "'" . $this->db->escape($description) . "')");
    }
  }

  protected function resortFields($doctype_uid)
  {
    //проверяем сортировку полей
    $query_field_sort = $this->db->query("SELECT field_uid, sort FROM " . DB_PREFIX . "field WHERE doctype_uid='" . $this->db->escape($doctype_uid) . "' ORDER BY sort ASC");
    $sort = 1;
    foreach ($query_field_sort->rows as $field) {
      $this->db->query("UPDATE " . DB_PREFIX . "field SET sort='" . (int)$sort++ . "' WHERE field_uid = '" . $field['field_uid'] . "'");
    }
  }

  protected function isTableColumn($table, $column = "")
  {
    $sql = "SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='" . DB_DATABASE . "' AND TABLE_NAME='" . DB_PREFIX . $this->db->escape($table) . "' ";
    if ($column) {
      $sql .= " AND COLUMN_NAME = '" . $this->db->escape($column) . "' ";
    }
    $query = $this->db->query($sql);
    return ($query->num_rows);
  }
}
