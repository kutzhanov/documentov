<?php
// Text
$_['text_license']       = 'Лицензия';
$_['text_installation']  = 'Предварительные требования';
$_['text_configuration'] = 'Конфигурация';
$_['text_upgrade']       = 'Обновление';
$_['text_finished']      = 'Завершено';
$_['text_language']      = 'Язык';