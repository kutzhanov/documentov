<?php
// Text
$_['text_project']       = 'Домашняя страница проекта';
$_['text_documentation'] = 'Документация';
$_['text_support']       = 'Форум подержки';
$_['text_footer']        = '© 2018 Documentov на архитектуре <a href="http://www.opencart.com/" target="_blank">OpenCart</a>';