<?php
// Button
$_['button_continue'] = 'Продолжить';
$_['button_back']     = 'Назад';

// Error
$_['error_exception'] = 'Код ошибки(%s): %s в %s на строке %s';