<?php
class ControllerCommonFooter extends Controller
{
  public function index()
  {
    $this->load->language('common/footer');

    $data['notification_pooling_period'] = $this->config->get('notification_pooling_period') ?? 0;

    if ($this->config->get('config_name') == "Documentov") {
      $data['powered'] = sprintf($this->language->get('text_powered'), "&copy; " . date('Y', time()), $this->config->get('config_name')) .  VERSION . $this->language->get('text_powered_addt');
    } else {
      $data['powered'] = strip_tags(sprintf($this->language->get('text_powered'), "", $this->config->get('config_name'), VERSION));
    }
    return $this->load->view('common/footer', $data);
  }
}
