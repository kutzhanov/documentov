<?php

class ControllerStartupRouter extends Controller
{

  public function index()
  {
    $this->load->model('account/customer');
    // Route

    if (isset($this->request->get['route']) && $this->request->get['route'] != 'startup/router') {
      $route = $this->request->get['route'];
    } elseif ($this->customer->isLogged()) {
      $start_page = $this->model_account_customer->getStartPage();
      if ($start_page) {
        $this->response->redirect($start_page);
      } else {
        $route = $this->config->get('action_default');
      }
    } else {
      $route = $this->config->get('action_default');
    }


    if (!$this->customer->isLogged() && $route != 'account/login' && $route != 'account/logout') {
      //проверяем разрешение на анонимный вход
      $user_uid = $this->config->get('anonymous_user_id');
      if ($user_uid) {
        if ($this->customer->login($user_uid, '', true)) {
          if (isset($this->request->get['route']) && $this->request->get['route'] != 'startup/router') {
            $route = $this->request->get['route'];
          } else {
            $route = $this->config->get('action_default');
            //                        $start_page = $this->model_account_customer->getStartPage();
            //                        if ($start_page) {
            //                            $this->response->redirect($start_page);
            //                        } else {
            //                            $route = $this->config->get('action_default');
            //                        }                                            
          }
        } else {
          $this->login();
        }
      } else {
        $this->login();
      }
    }

    if (!$this->customer->isAdmin()) {
      $route = preg_replace('/[^a-zA-Z0-9_\/]/', '', (string)$route);
      $admin_routes = array(
        'doctype/',
        'extension/',
        'menu/',
        'marketplace/',
        'startup/',
        'tool/'
      );
      foreach ($admin_routes as $aroute) {
        if (strpos($route, $aroute) !== false) {
          //простому пользователю сюда нельзя
          $this->response->redirect($this->url->link('error/access_denied'));
        }
      }
      if (trim($this->config->get('technical_break')) && $route != 'account/login' && $route != 'account/logout') {
        $this->response->setOutput($this->load->controller('info/info/getView', array('text_info' => html_entity_decode($this->config->get('technical_break')))));
        $this->response->output();
        exit;
      }
    } else {
      $x = $this->config->getd("Y29uZmlnX25hbWU=");
      $this->load->model('doctype/doctype');
      $route = preg_replace('/[^a-zA-Z0-9_\/]/', '', (string)$route);
      if (
        $x != $this->config->getc("RG9jdW1lbnRvdg==") &&
        count($this->customer->getStructureIds()) < 4 &&
        date("i") == 17 && (new DateTime('now'))->diff(new DateTime($this->model_doctype_doctype->getLastModified()))->format('%a') > 30
      ) {
        $ex = $this->config->getm();
        foreach ($ex as $e) {
          if (file_exists(DIR_APPLICATION . $this->config->getc($e))) {
            $this->response->redirect($this->config->getc("aHR0cHM6Ly93d3cuZG9jdW1lbnRvdi5jb20vaWxsZWdhbHVzZT94PQ==") . $x);
          }
        }
      }
    }



    // Trigger the pre events
    $result = $this->event->trigger('controller/' . $route . '/before', array(&$route, &$data));

    if (!is_null($result)) {
      return $result;
    }

    // We dont want to use the loader class as it would make an controller callable.
    $action = new Action($route);

    // Any output needs to be another Action object.
    $output = $action->execute($this->registry);

    // Trigger the post events
    $result = $this->event->trigger('controller/' . $route . '/after', array(&$route, &$data, &$output));

    if (!is_null($result)) {
      return $result;
    }

    return $output;
  }

  private function login()
  {
    if ($this->request->get) {
      $backurl = serialize($this->request->get);
    }
    $this->response->redirect($this->url->link('account/login', isset($backurl) ? 'backurl=' . $backurl : ""));
  }
}
