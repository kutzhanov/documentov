<?php

$_['text_send_mail']        = 'Отправка почты на %s';
$_['text_resending']        = 'Повторная отправка';
