<?php

$_['heading_title']                             = 'Сервисы';