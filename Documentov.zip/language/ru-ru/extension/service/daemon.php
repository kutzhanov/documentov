<?php

$_['heading_title']                             = 'Демон';

$_['service_setting']                           = 'У сервиса нет глобальных настроек';

$_['button_demon_start']                        = 'Запустить демон';
$_['button_demon_restart']                      = 'Перезапустить демон';
$_['button_demon_stop']                         = 'Остановить демон';
$_['text_daemon_task_log']                      = 'Лог:';
$_['button_refresh']                            = 'Обновить';
$_['text_demon_started']                        = 'Демон запущен';
$_['text_demon_stopped']                        = 'Демон остановлен';
$_['text_win_instruction']                      = 'Для запуска демона откройте на сервере командную строку Windows и введите команду <code>php %s/daemon.php start</code>. Окно не закрывайте.';
