<?php

$_['heading_title']                 = 'Создание';

$_['text_success']                  = 'Настройки действия сохранены';
$_['text_extension']                = 'Действия';
$_['text_create_document']          = 'Создание документа';


$_['error_permission']              = 'У вас нет прав на редактирование действия';

$_['action_setting']                = 'У действия нет настроек';

