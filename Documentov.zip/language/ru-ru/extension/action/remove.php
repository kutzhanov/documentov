<?php

$_['heading_title']                 = 'Удаление';