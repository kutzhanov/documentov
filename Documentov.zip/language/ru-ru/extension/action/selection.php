<?php

$_['heading_title']                 = 'Выборка';

$_['text_success']                  = 'Настройки действия сохранены';
$_['text_extension']                = 'Действия';

$_['error_permission']              = 'У вас нет прав на редактирование действия';

$_['action_setting']                = 'У действия нет настроек';

