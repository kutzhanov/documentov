<?php

$_['text_access_set']           = 'Доступ установлен';
$_['text_action_setting_error'] = 'Действие Доступ неправильно настроено';

$_['heading_title']                = 'Доступ';

$_['text_success']                = 'Настройки действия сохранены';
$_['text_extension']                = 'Действия';

$_['error_permission']                = 'У вас нет прав на редактирование действия';

$_['action_setting']                = 'У действия нет настроек';