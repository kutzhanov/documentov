<?php

$_['heading_title']                = 'Перенаправление';

$_['text_success']                = 'Настройки действия сохранены';
$_['text_extension']                = 'Действия';
$_['action_setting']                = 'У действия нет настроек';
